namespace lost_in_the_woods
{
    public abstract class BaseEntity{}
}