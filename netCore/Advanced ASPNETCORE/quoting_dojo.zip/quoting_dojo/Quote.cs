namespace quoting_dojo
{
    public class Quote{
        public string author{get;set;}
        public string text{get;set;}

    }
}